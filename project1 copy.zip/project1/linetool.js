class LineTool extends Tool{
    static POINT_RADIUS = 10;
    static SELECTION_PADDING = 20

    constructor() {
        super();
        this.points = []

        this.selectedPoint = null;
        this.pointMoved = false;
        this.building = true;
        this.isSelected = false;
    }

    handleMouseDown(event) {
        let mousePos = [event.clientX, event.clientY]
        
        this.isSelected = false;

        let lastPoint = null;
        let p = 0
        for( let point of this.points ) {
            let xSquared = (mousePos[0] - point[0]) * (mousePos[0] - point[0])
            let ySquared = (mousePos[1] - point[1]) * (mousePos[1] - point[1])

            if( xSquared + ySquared < LineTool.POINT_RADIUS*LineTool.POINT_RADIUS ) {
                this.selectedPoint = p;
                this.isSelected = true;
                break;
            }

            if( lastPoint !== null && !this.building ){
                let midPoint = [(point[0]+lastPoint[0])/2, (point[1]+lastPoint[1])/2]
                xSquared = (mousePos[0] - midPoint[0]) * (mousePos[0] - midPoint[0])
                ySquared = (mousePos[1] - midPoint[1]) * (mousePos[1] - midPoint[1])
    
                if( xSquared + ySquared < LineTool.POINT_RADIUS*LineTool.POINT_RADIUS ) {
                    this.points.splice(p,0,midPoint)
                    this.numClicked = 0;
                    this.selectedPoint = p;
                    this.isSelected = true;
                    break;
                }
            }

            lastPoint = point
            p += 1
        }

        return this.isSelected || this.building;
    }

    handleMouseUp(event) {
        if( this.building ) {
            if( this.selectedPoint == this.points.length - 1){
                this.building = false;
            }
            else {
                this.points.push([event.clientX, event.clientY])

            } 
        }
        else if( this.selectedPoint !== null ) {
            if( event.shiftKey ){
                this.points.splice( this.selectedPoint, 1)
            }
        }
        this.selectedPoint = null;
        return this.isSelected;
    }

    handleMouseMove(event){
        if(this.building) {
            return false;
        }

        if(this.selectedPoint !== null ){
            this.pointMoved = true;
            this.points[this.selectedPoint] = [event.clientX, event.clientY];
        }

        return this.selectedPoint !== null;
    }

    handleDoubleClick(event){
        return false;
    }

    render( canvas ) {
        let lastpoint = null;

        let minMaxX = [Infinity, -Infinity]
        let minMaxY = [Infinity, -Infinity]

        let ctx = canvas.getContext("2d")
        for( let point of this.points ){
            minMaxX[0] = Math.min(minMaxX[0], point[0])
            minMaxX[1] = Math.max(minMaxX[1], point[0])

            minMaxY[0] = Math.min(minMaxY[0], point[1])
            minMaxY[1] = Math.max(minMaxY[1], point[1])

            ctx.beginPath()
            ctx.arc(point[0], point[1], LineTool.POINT_RADIUS, 0, 2*Math.PI);
            ctx.fill();
            if( lastpoint !== null ) {
                ctx.beginPath()
                ctx.moveTo(lastpoint[0], lastpoint[1])
                ctx.lineTo( point[0], point[1]);
                ctx.stroke()

                let lastfill = ctx.fillStyle;
                ctx.fillStyle = 'rgba(0, 0, 255, 0.4)';
                let midpoint = [(point[0]+lastpoint[0])/2,(point[1]+lastpoint[1])/2]
                ctx.beginPath()
                ctx.arc(midpoint[0], midpoint[1], LineTool.POINT_RADIUS, 0, 2*Math.PI);
                ctx.fill();
                ctx.fillStyle = lastfill;

            }
            lastpoint = point;
        }

        if( this.isSelected) {
            ctx.strokeRect(minMaxX[0] - LineTool.SELECTION_PADDING, 
                minMaxY[0] - LineTool.SELECTION_PADDING, 
                Math.abs(minMaxX[1]-minMaxX[0]) + 2*LineTool.SELECTION_PADDING, 
                Math.abs(minMaxY[1]-minMaxY[0]) + 2*LineTool.SELECTION_PADDING)
        }
    }
}