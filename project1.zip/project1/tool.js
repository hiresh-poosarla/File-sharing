class Tool {
    handleMouseDown(event) {
        throw "This method must be implemented"
    }

    handleMouseUp(event) {
        throw "This method must be implemented"
    }

    handleMouseMove(event ){
        throw "This method must be implemented"
    }

    handleDoubleClick(event ){
        throw "This method must be implemented"
    }

    render( canvas ){
        throw "This method must be implemented"
    }
}